module.exports = {
  locales: ["en", "nl"],
  defaultLocale: "nl",
  prefixDefault: false,
};
